from distutils.core import setup
import py2exe

setup(packages=['PySide2'],console=['testForm.py'])