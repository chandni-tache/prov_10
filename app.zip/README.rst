#command used to run the code
#open cmd of window and use below command
#first go to path from cmd window where is code.

python testForm.py 
